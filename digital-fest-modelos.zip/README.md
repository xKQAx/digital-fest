# Digital Fest — figuras desde imágenes

Referencias generadas con la herramienta integrada de imágenes el 11 de noviembre de 2026:

- `references/caballero-oscuro.png`: jefe oscuro original de armadura de hierro y detalles de bronce.
- `references/robot-programador.png`: robot de programación con símbolo de código.
- `references/torre-backend.png`: torre de servidores que representa backend, arquitectura y bases de datos.

Los tres modelos GLB están terminados en `models/`. Se generaron desde estas imágenes con Hunyuan3D 2 Mini 1.1.0 mediante el MCP de Modly. Son mallas sin texturas, con material neutro: los colores, luces y ojos de las referencias no están incorporados.

## Entregables — 12 de noviembre de 2026

- `models/caballero-oscuro.glb`: 1.201.324 bytes, 50.000 triángulos.
- `models/robot-programador.glb`: 1.201.276 bytes, 50.000 triángulos.
- `models/torre-backend.glb`: 1.201.200 bytes, 50.000 triángulos.

Las tres mallas son cerradas. Los archivos incluyen normales para iluminación suave. Se centraron horizontalmente, se colocó la base en Y=0 y se normalizó la altura a una unidad (un metro según glTF). Las vistas PNG junto a cada modelo se renderizaron desde la geometría real para inspección, con sombreado plano; no son imágenes generadas por IA.

`originals/` conserva las salidas originales de Modly. La optimización se hizo localmente con PyMeshLab, porque el servicio de automatización Electron en 8766 no está disponible en la instalación actual. El script reproducible está en `../../tools/prepare_mesh.py`.

Parámetros de generación: 30 pasos, resolución octree 256, guidance 5.5, remesh none; semillas 411, 412 y 413, respectivamente.

Trabajos MCP:
- Caballero: `ae4e9ebc-c06a-43ee-970e-fb9a36f5aaab`. Archivo recuperado de `Default/1794419190_02664ead.glb` tras reiniciar Modly; el historial temporal del trabajo ya no estaba disponible. Identidad confirmada por inspección visual de la geometría.
- Robot: `af927cd0-6d58-4c38-b479-8b8446f8f078`, terminado correctamente.
- Torre: `2cc276f3-7dfb-403a-b218-2d28a34c4453`, terminado correctamente.

El MCP `modly-cli-mcp` está instalado globalmente, registrado como `modly` en Codex y conectado al chat. El cliente de diagnóstico `../../tools/modly-mcp-client.mjs` también permite llamar su protocolo stdio desde el terminal. La consulta `modly.health` respondió correctamente.

La etapa de geometría cumple el objetivo de tres GLB de menos de 5 MB cada uno. Quedan para una etapa posterior el texturizado y la app WebAR con cámara, captura y compartir. No hay todavía una app publicada.
